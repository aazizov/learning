# COMMAND

mvn spring-boot:run