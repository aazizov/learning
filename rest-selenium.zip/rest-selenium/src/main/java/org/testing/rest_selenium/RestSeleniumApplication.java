package org.testing.rest_selenium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestSeleniumApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestSeleniumApplication.class, args);
	}

}
