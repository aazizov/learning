package org.testing.rest_selenium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSeleniumApplicationTests {

	@Test
	void contextLoads() {
	}

}
